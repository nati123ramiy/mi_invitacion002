
// Placeholder para animaciones, formularios o juegos
console.log('Invitación activa para Nataniel');
